<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="<?php echo URL_ROOT; ?>/css/jquery-ui.css">
  <title><?php echo SITE_NAME; ?></title>
</head>

<body>
  <?php require APP_ROOT . '/views/inc/navbar.php'; ?>
  <div class="container">
