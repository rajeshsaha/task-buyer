		</div>
		<script src="<?php echo URL_ROOT; ?>/js/jquery-3.6.0.min.js"></script>
		<script src="<?php echo URL_ROOT; ?>/js/jquery-ui.min.js"></script>
		<script src="<?php echo URL_ROOT; ?>/js/jquery.validate.min.js"></script>
		<script src="<?php echo URL_ROOT; ?>/js/main.js"></script>
	</body>
</html>