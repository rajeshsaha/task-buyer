<div>
  <ul>
    <li><a href="<?php echo URL_ROOT;?>">Form Submisison</a></li>
    <li><a href="<?php echo URL_ROOT;?>/reports">Report</a></li>
  </ul>
</div>