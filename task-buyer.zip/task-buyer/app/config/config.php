<?php
// DB Params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'buyer_report');
define("TABLE_NAME", "buyers");
define('DB_CHARSET', 'utf8');

define('APP_ROOT', dirname(dirname(__FILE__)));
define('URL_ROOT', '/task-buyer');
define('SITE_NAME', 'Buyer Merge');

define('APP_DATE_TIME_FORMAT', 'd/m/Y H:i:s');
