<?php

error_reporting(-1);
ini_set('display_errors', 'On');

require_once '../app/bootstrap.php';

// init core library
$init = new Core();